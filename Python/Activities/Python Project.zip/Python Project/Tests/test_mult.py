
# Multiplication test
	
def test_multiplication():
	
  
	
	# Initialize two numbers
	
	num1 = 5
	
	num2 = 20
	   
	
	# Multiply them
	
	prod = num1 * num2
	
	
	# Assertion
	
	assert prod == 100