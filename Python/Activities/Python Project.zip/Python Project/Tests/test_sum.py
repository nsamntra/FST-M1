import pytest

# Additon test
def test_addition():
	
    # Initialize two numbers
	num1 = 10
	num2 = 15
    
	# Add them
	sum = num1 + num2

	# Assertion
	assert sum == 25

