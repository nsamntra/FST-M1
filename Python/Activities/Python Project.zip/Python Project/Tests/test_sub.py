import pytest

# Subtraction test
	
def test_subtraction():

	# Initialize two numbers
	
	num1 = 50
	
	num2 = 35
	
	
	# Subtract them
	
	diff = num1 - num2
	
	
	# Assertion
	
	assert diff == 15
