
	
# Division test
	
def test_division():
	
  
	
	# Initialize two numbers
	
	num1 = 100
	
	num2 = 5
	
    
	
	# Divide them
	
	quot = num1 / num2
	
 
	
	# Assertion
	
	assert quot == 20