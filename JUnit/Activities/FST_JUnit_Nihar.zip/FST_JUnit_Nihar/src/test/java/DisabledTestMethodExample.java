import org.junit.jupiter.api.Disabled;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class DisabledTestMethodExample {
    // Ignored test method
    @Disabled("Disabled until CustomerService is up!")
    @Test
    void testCustomerServiceGet() {
        assertEquals(2, 1 + 1);
    }

    // Test method that will execute
    @Test
    void test3Plus3() {
        assertEquals(6, 3 + 3);
    }
}

