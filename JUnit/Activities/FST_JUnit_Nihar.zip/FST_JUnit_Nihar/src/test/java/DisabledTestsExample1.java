import org.junit.jupiter.api.Disabled;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static org.junit.jupiter.api.Assertions.assertEquals;


    // @Disable on a class with a message
    @Disabled("Disabled until bug #2020 has been fixed!")
    public class DisabledTestsExample1 {
        // All test methods are ignored
        @Test
        void test1Plus1() {
            assertEquals(2, 1 + 1);
        }

        @Test
        void test2Plus2() {
            assertEquals(4, 2 + 2);
        }
    }

